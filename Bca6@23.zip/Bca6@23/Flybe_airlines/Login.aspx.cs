﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void Button_Submit_Click1(object sender, EventArgs e)
    {

        string unm, pwd;
        unm = TextBox_User.Text;
        pwd = TextBox_Pwd.Text;

        if (unm != "" && pwd != "")
        {
            Session["user"] = unm;
            Response.Redirect("booking.aspx");
        }
        else {
            Response.Write("login denied");
        }
     
    }
}