﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button_Submit_Click(object sender, EventArgs e)
    {
        string unm, pwd;
        unm = TextBox_Username.Text;
        pwd = TextBox_Password.Text;

        if (TextBox_Username.Text == "admin" && TextBox_Password.Text == "admin")
        {
            Session["user"] = unm;
            Response.Redirect("Admin home.aspx");
        }
        else
        {
            Label_Message.Visible = true;
        }


    }
}