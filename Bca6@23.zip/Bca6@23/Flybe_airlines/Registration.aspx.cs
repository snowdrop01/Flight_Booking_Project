﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Configuration;


public partial class _Default: System.Web.UI.Page
{   
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\PC73\Documents\Visual Studio 2012\WebSites\WebSite18\Flybe_airlines\App_Data\Database.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        con.Open();

        SqlCommand cm = new SqlCommand("select *from registration", con);
        SqlDataReader dr = cm.ExecuteReader();
        con.Close();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string qry = "insert into registration values('" + TextBox1.Text+"','"+TextBox3.Text+"','"+TextBox6.Text+"','"+DropDownList1.SelectedValue+"','"+TextBox5.Text+"','"+TextBox4.Text+"')";
        SqlCommand cmd = new SqlCommand(qry,con);
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Write("<script>alert('your Registerd succesfully')</script>");
        Response.Redirect("login.aspx");
    }

    
}