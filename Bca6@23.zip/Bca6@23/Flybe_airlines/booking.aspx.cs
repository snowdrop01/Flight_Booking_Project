﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\PC73\Documents\Visual Studio 2012\WebSites\WebSite18\Flybe_airlines\App_Data\Database.mdf;Integrated Security=True;Connect Timeout=30");
    SqlCommand cm = new SqlCommand();
    public void add_default_flight_from_to()
    {
        DropDownList3.SelectedIndex = 0;
        DropDownList1.SelectedIndex = 0;
        DropDownList2.SelectedIndex = 0;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        con.Open();
        if (Session["user"] == null)
        {
            Response.Redirect("login.aspx");
        }
        SqlCommand cm = new SqlCommand("select *from booking", con);
        SqlDataReader dr = cm.ExecuteReader();
        con.Close();
    }
    protected void Button_Submit_Click(object sender, EventArgs e)
    {
        con.Open();
        string qry = "insert into booking values('" + tb_date.Text + "','" +DropDownList3.SelectedValue + "','" + DropDownList1.SelectedValue + "','"+DropDownList2.SelectedValue +"','"+TextBox_DestinationCity.Text+"','"+TextBox2.Text+"','"+ TextBox_add.Text+"','"+TextBox_DepartureTime.Text+"','"+TextBox_email.Text+"')";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("<script>alert('your Flight is Booked succesfully " + TextBox_DestinationCity.Text + "')</script>");
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList3.SelectedValue == "Indigo")
        {
            lbl_price.Text="RS.4500";
        }
        else if (DropDownList3.SelectedValue == "SpiceJet")
        {
            lbl_price.Text="RS.5000";
        }
        else if (DropDownList3.SelectedValue == "AirIndia")
        {
            lbl_price.Text="RS.4000";
        }
        else if (DropDownList3.SelectedValue == "JetAirways")
        {
            lbl_price.Text="RS.6000";
        }
        else
        {
            lbl_price.Text="RS.0000";
        }
        //Response.Write("your Flight is Booked");
//        Response.Write("<script>alert('your Flight is Booked succesfully "+TextBox_DestinationCity.Text+"[][]')</script>");
    }
}
    